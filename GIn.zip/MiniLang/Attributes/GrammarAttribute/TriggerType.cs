﻿namespace MiniLang.Attributes.GrammarAttribute
{
    public enum TriggerType
    {
        Type,
        Operator
    }
}
