﻿namespace MiniLang.TokenObjects;
public enum TokenTree
{
    Single,
    Group
}
