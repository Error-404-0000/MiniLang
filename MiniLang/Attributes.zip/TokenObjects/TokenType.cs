﻿using MiniLang.Attributes;

namespace MiniLang.TokenObjects;
public enum TokenType
{
    None,

    [ValueContainer(false, "=")]
    SETTER,

    [ValueContainer(true, "say", "show")]
    Function,

    Number,
    Scope,
    [ValueContainer(true, "+", "-", "*", "/", "%", "^")]
    Operation,

    [ValueContainer(false, "(")]
    ParenthesisOpen,
    [ValueContainer(false, ")")]
    ParenthesisClose,

    [ValueContainer(true, "if", "else", "and", "or", "not")]
    Conditions,

    [ValueContainer(true, "use", "make", "give")]
    Keyword,

    [ValueContainer(false, "{")]
    CurlybracketStart,
    [ValueContainer(false, "}")]
    CurlybracketEnds,
    [ValueContainer(false, ":")]
    Then,
    [ValueContainer(false, "done")]
    Done,
    [ValueContainer(false,";")]
    Semicolon,
    [ValueContainer(false, ".")]
    Dot,

    StringLiteralExpression,
    [ValueContainer(false, ",")]
    Comma,
    CharLiteralExpression,
    Identifier,

    [ValueContainer(false, "give")]
    Return,

    [ValueContainer(false,"fn")]
    NewFunction,
    

}
