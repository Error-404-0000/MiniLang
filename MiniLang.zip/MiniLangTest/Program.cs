﻿using MiniLang.Debugger;
using MiniLang.Parser;
using MiniLang.Tokenilzer;

var tokens = Tokenizer.Tokenize(@"using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
include Windowapi.h
class Program
{
    static void Main()
    {
var TokensParsed = Parser.Parse(tokens);

Debugger.WriteTree(TokensParsed);
var TokensParsed = Parser.Parse(tokens);

Debugger.WriteTree(TokensParsed);
        int e = 299*4;
        Console.WriteLine(""Hello   ee."",3);
var User = ((((((2 + 0) + 3) * ((4 * 1) + (0 + 5))) + 2) / (((6 + 6) * 1) * (1 + 0 + 1))) +
((100 / 5) - ((3 + 2) + 0))) +
(((7 * 8) + (9 - 4 + 0)) * (((2 + 3 + 0) * 1) + 2)) -
(((10 + 0 + 5) * 1) * ((6 - 0 - 1))) +
((((50 + 50) / 2) * (((3 + 2) - 0) - (1 + 1)))) + 0 + 0 * 1234 + Add(Pow(20,Sin((20/1*90)+Add(60,70)+90)),20)
    }
}
");
var TokensParsed = Parser.Parse(tokens);

Debugger.WriteTree(TokensParsed);