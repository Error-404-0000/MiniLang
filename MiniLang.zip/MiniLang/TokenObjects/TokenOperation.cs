﻿namespace MiniLang.TokenObjects;

using MiniLang.Attributes;

public enum TokenOperation
{

    None = 0,
   
    #region Operations
    
    [ValueContainer(false, "+")]
    AddOperation,

   
    [ValueContainer(false, "-")]
    SubtractOperation,

   
    [ValueContainer(false, "*")]
    MultiplyOperation,

    
    [ValueContainer(false, "/")]
    DivideOperation,

  
    [ValueContainer(false, "^")]
    PowerOperation,

  
    [ValueContainer(false, "<")]
    ShiftLeftOperation,

    [ValueContainer(false, ">")]
    ShiftRightOperation,

  
    [ValueContainer(false, "|")]
    OROperation,

   
    [ValueContainer(false, "&")]
    ANDOperation,

   
    [ValueContainer(false, "%")]
    Reminder,


    #endregion

    #region Keywords
    [ValueContainer(false, "nameof")]
    nameof,
    [ValueContainer(false, "include")]
    include,
    [ValueContainer(false, "sizeof")]
    @sizeof,
    [ValueContainer(false, "using")]
    @using,
    [ValueContainer(false, "class")]
    @class,
    [ValueContainer(false, "void")]
    @void,
    [ValueContainer(false, "static")]
    @static,
    [ValueContainer(false, "public")]
    @public,
    [ValueContainer(false, "var")]
    var,
    #endregion
    #region Conditions

    [ValueContainer(false,"eq")]
    eq,
    [ValueContainer(false, "neq")]
    neq,
    [ValueContainer(false, "lt")]
    lt,
    [ValueContainer(false, "gt")]
    gt,
    [ValueContainer(false, "if")]
    If,
    [ValueContainer(false, "else")]
    @else,




    #endregion
}
