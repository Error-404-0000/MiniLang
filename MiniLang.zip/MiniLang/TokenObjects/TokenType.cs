﻿using MiniLang.Attributes;

namespace MiniLang.TokenObjects;
public enum TokenType
{
    None,
    [ValueContainer(false, "=")]
    SETTER,
    [ValueContainer(true,  "Print")]
    Function,
    Number,
    [ValueContainer(true, "+", "-", "/", "*", "^", "&", "<", ">", "|", "%")]
    Operation,
    [ValueContainer(false, "(")]
    ParenthesisOpen,
    [ValueContainer(false, ")")]
    ParenthesisClose,
    [ValueContainer(true, "eq", "neq", "gt", "lt", "if", "else")]
    Conditions,
    [ValueContainer(true, "include", "namespace", "nameof","include","sizeof","using","class","void","static","var")]
    Keyword,
    [ValueContainer(false, "{")]
    CurlybracketStart,
    [ValueContainer(false, "}")]
    CurlybracketEnds,
    [ValueContainer(false, ";")]
    Semicolon,
    [ValueContainer(false, ".")]
    Dot,
    
    StringLiteralExpression,
    [ValueContainer(false, ",")]
    Comma,
    Identifier,


}
