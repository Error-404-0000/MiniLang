﻿using System;
using System.Collections.Generic;
using System.Text;
namespace MiniLang.Tokenilzer;
public static class Tokenizer
{
    public static string[] Tokenize(string input)
    {
        input = input.Replace("\r\n", "");

        List<string> tokens = new();
        StringBuilder currentToken = new();
        bool isString = false;

        for (int i = 0; i < input.Length; i++)
        {
            char c = input[i];

            if (c == '"')
            {
                if (isString)
                {
                    currentToken.Append(c);
                    tokens.Add(currentToken.ToString());
                    currentToken.Clear();
                    isString = false;
                }
                else
                {
                    if (currentToken.Length > 0)
                    {
                        tokens.Add(currentToken.ToString());
                        currentToken.Clear();
                    }
                    isString = true;
                    currentToken.Append(c);
                }
                continue;
            }

            if (isString || (!char.IsWhiteSpace(c) && !IsSeparator(c)))
            {
                currentToken.Append(c);
            }
            else
            {
                if (currentToken.Length > 0)
                {
                    tokens.Add(currentToken.ToString());
                    currentToken.Clear();
                }

                if (IsSeparator(c))
                {
                    tokens.Add(c.ToString());
                }
            }
        }

        if (currentToken.Length > 0)
        {
            tokens.Add(currentToken.ToString());
        }

        return tokens.ToArray();
    }
    private static bool IsSeparator(char c)
    {
        return char.IsPunctuation(c) || char.IsSymbol(c);
    }
    public static bool IsFunctionName(string str)
    {
      
        return str.Length>0 && isChar(str[0]);
    }
    public static bool isChar(char ch)
    {

        return ch is >= 'a' and <= 'z' || ch is >= 'A' and <= 'Z';
    }
    public static bool IsNumber(string numstr)
    {
        bool hitdot = false;
        for (int i = 0; i < numstr.Length; i++)
        {
            if (numstr[i] >= '0' && numstr[i] <= '9')
                continue;
            if (hitdot is false && numstr[i] == '.')
            {
                if (i + 1 < numstr.Length && IsNumber(numstr[i + 1]))
                {
                    hitdot = true;
                    continue;
                }
            }
            return false;
        }
        return true;
    }
    private static bool IsNumber(char num)
    {

        return num >= '0' && num <= '9';
    }
}